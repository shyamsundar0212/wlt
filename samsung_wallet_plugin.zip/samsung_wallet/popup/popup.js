document.addEventListener('DOMContentLoaded', function() {
  const loginSection = document.getElementById('login-section');
  const walletSection = document.getElementById('wallet-section');
  const loginButton = document.getElementById('login-button');
  const addWalletButton = document.getElementById('add-wallet-button');
  const logoutButton = document.getElementById('logout-button');
  const userNameSpan = document.getElementById('user-name');
  const messageDiv = document.getElementById('message');

  // Detect the browser API
  const browserAPI = (typeof browser === "undefined") ? chrome : browser;

  let currentBankName = '';

  // Check if user is already logged in
  browserAPI.storage.sync.get(['username', 'loginTime'], function(data) {
    if (data.username && data.loginTime) {
      const loginTime = new Date(data.loginTime);
      const now = new Date();
      if ((now - loginTime) < 24 * 60 * 60 * 1000) { // Check if login is within 24 hours
        loginSection.style.display = 'none';
        walletSection.style.display = 'block';
        userNameSpan.textContent = data.username;
      } else {
        browserAPI.storage.sync.remove(['username', 'loginTime']);
      }
    }
  });

  loginButton.addEventListener('click', function() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!emailPattern.test(username)) {
      alert('Please enter a valid email address.');
      return;
    }

    if (password.length < 8) {
      alert('Password must be at least 8 characters long.');
      return;
    }

    // Allow all users to log in without verification
    browserAPI.storage.sync.set({ username: username, loginTime: new Date().toString() }, function() {
      loginSection.style.display = 'none';
      walletSection.style.display = 'block';
      userNameSpan.textContent = username;
    });
  });

  addWalletButton.addEventListener('click', function() {
    if (currentBankName) {
      callAddBankAPI(currentBankName);
    } else {
      alert('No bank name detected to add.');
    }
  });

  logoutButton.addEventListener('click', function() {
    browserAPI.storage.sync.remove(['username', 'loginTime'], function() {
      loginSection.style.display = 'block';
      walletSection.style.display = 'none';
    });
  });

  browserAPI.tabs.query({ active: true, currentWindow: true }, function(tabs) {
    const activeTab = tabs[0];
    const currentUrl = new URL(activeTab.url);
    checkBankSite(currentUrl.hostname);
  });

  function checkBankSite(hostname) {
    const bankData = [
      { url: "onlinesbi.sbi", name: "SBI" },
      { url: "axisbank.com", name: "AXIS" },
      { url: "unionbankofindia.co.in", name: "UNION" },
      { url: "icicibank.com", name: "ICICI" }
    ];

    const matchedBank = bankData.find(bank => hostname.includes(bank.url));

    if (matchedBank) {
      currentBankName = matchedBank.name;
      messageDiv.textContent = `Do you like to add ${currentBankName} Bank account into the wallet?`;
    } else {
      messageDiv.textContent = 'Not a supported bank site or unable to detect bank name';
    }
  }

  function callAddBankAPI(bankName) {
    // Call your API here
    console.log(`API called to add ${bankName} to wallet`);
    alert('Addition of your bank account has been initiated');
  }
});
