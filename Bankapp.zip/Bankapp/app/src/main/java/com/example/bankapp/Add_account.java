package com.example.bankapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.button.MaterialButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class Add_account extends AppCompatActivity {
    EditText acc_name,acc_branch,acc_ifsc,acc_bank,acc_number;
    Button acc_Add;
    FirebaseAuth fauth;
    FirebaseFirestore db;
    String User,Phone_no;
    DocumentReference docref;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_account);
        acc_name=findViewById(R.id.acc_name);
        acc_number=findViewById(R.id.acc_number);
        acc_bank=findViewById(R.id.acc_bank);
        acc_branch=findViewById(R.id.acc_branch);
        acc_ifsc=findViewById(R.id.acc_ifsc);
        acc_Add=findViewById(R.id.acc_add);
        fauth=FirebaseAuth.getInstance();
        User=fauth.getCurrentUser().getUid();

        db=FirebaseFirestore.getInstance();
        docref=db.collection("users").document(User);
        docref.get()
                        .addOnSuccessListener(new OnSuccessListener<DocumentSnapshot>() {
                            @Override
                            public void onSuccess(DocumentSnapshot documentSnapshot) {
                                if(documentSnapshot.exists()){
                                    Phone_no=documentSnapshot.getString("phone_no");
                                }
                                else{
                                    Toast.makeText(Add_account.this,"user haven't provided correct phone number",Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
                                .addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Add_account.this,"Error fetching deatils "+e.getMessage(),Toast.LENGTH_SHORT).show();

                                    }
                                });
        acc_Add.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                String acc_Name=acc_name.getText().toString();
                String acc_Branch=acc_branch.getText().toString();
                String acc_Ifsc=acc_ifsc.getText().toString();
                String acc_Number=acc_number.getText().toString();
                String acc_Bank=acc_bank.getText().toString();
                Map<String,Object> user=new HashMap<>();
                        user.put("name",acc_Name);
                        user.put("acc_num",acc_Number);
                        user.put("bank_name",acc_Bank);
                        user.put("IFSC",acc_Ifsc);
                        user.put("branch_name",acc_Branch);
                        db.collection("accounts").document(Phone_no).collection("bank_details").document(acc_Number).set(user)
                                .addOnSuccessListener(new OnSuccessListener<Void>() {
                                    @Override
                                    public void onSuccess(Void aVoid) {
                                        Toast.makeText(Add_account.this,"Succesfully Added",Toast.LENGTH_SHORT).show();
                                        finish();
                                    }
                                }).addOnFailureListener(new OnFailureListener() {
                                    @Override
                                    public void onFailure(@NonNull Exception e) {
                                        Toast.makeText(Add_account.this,"Addition Failed",Toast.LENGTH_SHORT).show();
                                    }
                                });
            }
        });
    }
}
