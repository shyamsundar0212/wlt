package com.example.bankapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class myadapter1 extends RecyclerView.Adapter<myadapter1.MyViewHolder> {
    Context context;
    ArrayList<account> accounts;

    public myadapter1(Context context, ArrayList<account> accounts) {
        this.context = context;
        this.accounts = accounts;
    }

    @NonNull
    @Override
    public myadapter1.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.item_txn,parent,false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull myadapter1.MyViewHolder holder, int position) {
       account acc=accounts.get(position);
        Timestamp timestamp = acc.getTime();

        // Convert Timestamp to Date
        Date date = timestamp.toDate();

        // Format Date to String
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault());
        String dateString = sdf.format(date);
       holder.acc_no.setText(acc.acc_no);
       if(acc.money<0) holder.money.setTextColor(Color.RED);
       else holder.money.setTextColor(Color.GREEN);
       holder.money.setText(String.valueOf(acc.money)+"$");
       holder.time.setText(dateString);
    }

    @Override
    public int getItemCount() {
        return accounts.size();
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder{
        TextView acc_no,time,money;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            acc_no=itemView.findViewById(R.id.txn_accno);
            time=itemView.findViewById(R.id.date_txn);
            money=itemView.findViewById(R.id.amount);
        }
    }
}
