package com.example.bankapp;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    static Context context;
    static ArrayList<User> userArrayList;

    public MyAdapter(Context context, ArrayList<User> userArrayList) {
        this.context = context;
        this.userArrayList = userArrayList;
    }

    @NonNull
    @Override
    public MyAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v= LayoutInflater.from(context).inflate(R.layout.item,parent,false);

        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyAdapter.MyViewHolder holder, int position) {
   User user=userArrayList.get(position);
   holder.name.setText(user.name);
   holder.bank_name.setText(user.bank_name);
   holder.acc_num.setText(user.acc_num);

    }

    @Override
    public int getItemCount() {
        return userArrayList.size();
    }
    public static class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
          TextView name,bank_name,acc_num;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            name=itemView.findViewById(R.id.card_name);
            bank_name=itemView.findViewById(R.id.card_bankname);
            acc_num=itemView.findViewById(R.id.card_accno);
              itemView.setOnClickListener(this);
        }
        @Override
        public void onClick(View v){
            int position=getAdapterPosition();
            //Toast.makeText(context,"position"+position,Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(context,wallet_intro.class);
            intent.putExtra("acc_num",userArrayList.get(position).getAcc_num());
            context.startActivity(intent);
        }
    }
}
