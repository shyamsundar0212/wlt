package com.example.bankapp;

public class User {
    public String name;
    public String bank_name;
    public String acc_num;
    String IFSC;
    String branch_name;
    public User(){}
    public User(String name, String bank_name, String acc_num, String IFSC, String branch_name) {
        this.name = name;
        this.bank_name = bank_name;
        this.acc_num = acc_num;
        this.IFSC = IFSC;
        this.branch_name = branch_name;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getbank_name() {
        return bank_name;
    }

    public void setbank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getAcc_num() {
        return acc_num;
    }

    public void setAcc_num(String acc_num) {
        this.acc_num = acc_num;
    }

    public String getIFSC() {
        return IFSC;
    }

    public void setIFSC(String IFSC) {
        this.IFSC = IFSC;
    }

    public String getbranch_name() {
        return branch_name;
    }

    public void setbranch_name(String branch_name) {
        branch_name = branch_name;
    }
}
