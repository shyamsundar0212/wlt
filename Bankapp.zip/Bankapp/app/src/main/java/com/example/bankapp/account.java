package com.example.bankapp;

import com.google.firebase.Timestamp;

public class account {
    String acc_no;
    double money;
    Timestamp time;
    boolean credit;
    public account(){}
    public account(String acc_no, double money, Timestamp time, boolean credit) {
        this.acc_no = acc_no;
        this.money = money;
        this.time = time;
        this.credit = credit;
    }

    public String getAcc_no() {
        return acc_no;
    }

    public void setAcc_no(String acc_no) {
        this.acc_no = acc_no;
    }

    public double getMoney() {
        return money;
    }

    public void setMoney(double money) {
        this.money = money;
    }

    public Timestamp getTime() {
        return time;
    }

    public void setTime(Timestamp time) {
        this.time = time;
    }

    public boolean isCredit() {
        return credit;
    }

    public void setCredit(boolean credit) {
        this.credit = credit;
    }
}
