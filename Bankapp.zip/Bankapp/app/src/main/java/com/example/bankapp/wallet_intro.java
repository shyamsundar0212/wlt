package com.example.bankapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class wallet_intro extends AppCompatActivity {
    private static final String TAG = "WalletIntroActivity";

    TextView name, account, branchname, bankname, ifsc, phone_no;
    FirebaseFirestore db;
    FirebaseAuth fauth;
    String User;
    String Phone_no;
    RecyclerView recyclerView;
    myadapter1 myad;
    ArrayList<account> accounts;
    String acc_no;
    ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_wallet_intro);

        Intent intent = getIntent();
        acc_no = intent.getStringExtra("acc_num");

        account = findViewById(R.id.details_accno);
        name = findViewById(R.id.details_name);
        branchname = findViewById(R.id.details_branch);
        bankname = findViewById(R.id.details_bank);
        ifsc = findViewById(R.id.details_ifsc);
        phone_no = findViewById(R.id.details_contact);

        fauth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = fauth.getCurrentUser();
        Button buttonOpenApp = findViewById(R.id.wallet_btn);
        buttonOpenApp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openAnotherApp();
            }
        });
        if (currentUser == null) {
            Log.e(TAG, "User not authenticated");
            Toast.makeText(this, "User not authenticated", Toast.LENGTH_SHORT).show();
            return;
        }

        User = currentUser.getUid();

        DocumentReference userDocumentReference = db.collection("users").document(User);
        userDocumentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e(TAG, "Listen failed.", error);
                    return;
                }

                if (documentSnapshot != null && documentSnapshot.exists()) {
                    Phone_no = documentSnapshot.getString("phone_no");
                    phone_no.setText(Phone_no);
                    Log.d(TAG, "Phone number: " + Phone_no);

                    fetchAccountDetails(acc_no);
                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
        progressDialog=new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data");
        recyclerView=findViewById(R.id.recyclerView_txns);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        accounts=new ArrayList<account>();
        myad=new myadapter1(wallet_intro.this,accounts);
        recyclerView.setAdapter(myad);
        EventchangeListner();
    }

    private void EventchangeListner() {
        db.collection("Transactions").document(acc_no).collection("app_txns")
                .orderBy("time", Query.Direction.DESCENDING)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
            @Override
            public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
               if(error!=null){
                   if(progressDialog.isShowing())
                       progressDialog.dismiss();
                   Log.e("Firestore transaction retrieve error",error.getMessage());
                   return;
               }
               for(DocumentChange dc:value.getDocumentChanges()){
                   if(dc.getType()==DocumentChange.Type.ADDED){
                       accounts.add(dc.getDocument().toObject(account.class));
                   }

                   myad.notifyDataSetChanged();
                   if(progressDialog.isShowing())
                       progressDialog.dismiss();
               }
            }
        });
    }

    private void fetchAccountDetails(String acc_no) {
        if (Phone_no == null || Phone_no.isEmpty()) {
            Log.e(TAG, "Phone number is null or empty");
            Toast.makeText(this, "Phone number not available", Toast.LENGTH_SHORT).show();
            return;
        }

        DocumentReference accountDoc = db.collection("accounts").document(Phone_no)
                .collection("bank_details").document(acc_no);

        accountDoc.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {

                    Log.e(TAG, "Listen failed.", error);
                    return;
                }

                if (documentSnapshot != null && documentSnapshot.exists()) {
                    name.setText(documentSnapshot.getString("name"));
                    bankname.setText(documentSnapshot.getString("bank_name"));
                    branchname.setText(documentSnapshot.getString("branch_name"));
                    ifsc.setText(documentSnapshot.getString("IFSC"));
                    account.setText(documentSnapshot.getString("acc_num"));
                } else {
                    Log.d(TAG, "No such document");
                }
            }
        });
    }
    private void openAnotherApp() {
        Intent launchIntent = getPackageManager().getLaunchIntentForPackage("com.example.walletapp");
        if (launchIntent != null) {
            startActivity(launchIntent);
        } else {
            // The application is not installed, you can show a message or redirect to Play Store
            Toast.makeText(this, "App not installed", Toast.LENGTH_SHORT).show();
//            Intent goToMarket = new Intent(Intent.ACTION_VIEW)
//                    .setData(Uri.parse("market://details?id=com.example.walletapp"));
//            startActivity(goToMarket);
        }
    }
}
