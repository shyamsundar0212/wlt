package com.example.walletapp;

import static android.content.ContentValues.TAG;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentChange;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class wallet extends Fragment implements MyAdapter.OnAccountClickListener {
    RecyclerView recyclerViewWallet, recyclerViewNotInWallet;
    ArrayList<User> userArrayListWallet, userArrayListNotInWallet;
    MyAdapter myAdapterWallet, myAdapterNotInWallet;
    FirebaseFirestore db;
    FirebaseAuth auth;
    String user;
    String Phone_no;
    ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_wallet, container, false);

        // Initialize RecyclerViews
        recyclerViewWallet = view.findViewById(R.id.accounts_wallet);
        recyclerViewNotInWallet = view.findViewById(R.id.accounts_not_in_wallet);

        recyclerViewWallet.setHasFixedSize(true);
        recyclerViewWallet.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerViewNotInWallet.setHasFixedSize(true);
        recyclerViewNotInWallet.setLayoutManager(new LinearLayoutManager(getContext()));

        db = FirebaseFirestore.getInstance();
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser().getUid();

        progressDialog = new ProgressDialog(getContext());
        progressDialog.setCancelable(false);
        progressDialog.setMessage("Fetching data");

        userArrayListWallet = new ArrayList<>();
        userArrayListNotInWallet = new ArrayList<>();

        myAdapterWallet = new MyAdapter(getContext(), userArrayListWallet, this);
        myAdapterNotInWallet = new MyAdapter(getContext(), userArrayListNotInWallet, this);

        recyclerViewWallet.setAdapter(myAdapterWallet);
        recyclerViewNotInWallet.setAdapter(myAdapterNotInWallet);

        // Fetch phone number and set up listener
        fetchPhoneNumberAndSetListener();

        return view;
    }

    private void fetchPhoneNumberAndSetListener() {
        DocumentReference userDocumentReference = db.collection("users").document(user);
        userDocumentReference.addSnapshotListener(new EventListener<DocumentSnapshot>() {
            @Override
            public void onEvent(@Nullable DocumentSnapshot documentSnapshot, @Nullable FirebaseFirestoreException error) {
                if (error != null) {
                    Log.e(TAG, "Listen failed.", error);
                    return;
                }

                if (documentSnapshot != null && documentSnapshot.exists()) {
                    Phone_no = documentSnapshot.getString("phone_no");
                    Log.d(TAG, "Phone number: " + Phone_no);
                    // Set up event listener for accounts collection
                    EventChangeListener();
                } else {
                    Log.d(TAG, "Current data: null");
                }
            }
        });
    }

    private void EventChangeListener() {
        if (Phone_no == null || Phone_no.isEmpty()) {
            Log.e(TAG, "Phone number is null or empty.");
            return;
        }

        progressDialog.show();

        db.collection("accounts").document(Phone_no).collection("cards")
                .orderBy("expiry", Query.Direction.ASCENDING)
                .addSnapshotListener(new EventListener<QuerySnapshot>() {
                    @Override
                    public void onEvent(@Nullable QuerySnapshot value, @Nullable FirebaseFirestoreException error) {
                        if (error != null) {
                            if (progressDialog.isShowing())
                                progressDialog.dismiss();
                            Log.e("Firestore transaction retrieve error", error.getMessage());
                            return;
                        }

                        userArrayListWallet.clear();
                        userArrayListNotInWallet.clear();

                        for (DocumentChange dc : value.getDocumentChanges()) {
                            if (dc.getType() == DocumentChange.Type.ADDED) {
                                User user = dc.getDocument().toObject(User.class);
                                if (user.isSamsung_wallet()) {
                                    userArrayListWallet.add(user);
                                } else {
                                    userArrayListNotInWallet.add(user);
                                }
                            }
                        }

                        myAdapterWallet.notifyDataSetChanged();
                        myAdapterNotInWallet.notifyDataSetChanged();
                        if (progressDialog.isShowing())
                            progressDialog.dismiss();
                    }
                });
    }

    @Override
    public void onAccountClick(User user) {
        if (user.isSamsung_wallet()) {
            showRemoveAccountDialog(user);
        } else {
            showAddAccountDialog(user);
        }
    }

    private void showAddAccountDialog(User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage("Do you want to add this account to Samsung Wallet?")
                .setPositiveButton("OK", (dialog, id) -> updateSamsungWalletStatus(user, true))
                .setNegativeButton("Cancel", null);
        builder.create().show();
    }

    private void showRemoveAccountDialog(User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
        builder.setMessage("Do you want to remove this account from Samsung Wallet?")
                .setPositiveButton("OK", (dialog, id) -> updateSamsungWalletStatus(user, false))
                .setNegativeButton("Cancel", null);
        builder.create().show();
    }

    private void updateSamsungWalletStatus(User user, boolean status) {
        // Query to find the document with the matching acc_num
        db.collection("accounts").document(Phone_no).collection("cards")
                .whereEqualTo("acc_num", user.getAcc_num())
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        if (task.getResult() != null && !task.getResult().isEmpty()) {
                            // Assuming acc_num is unique within the collection
                            DocumentSnapshot document = task.getResult().getDocuments().get(0);

                            // Update the document with the matching acc_num
                            document.getReference().update("samsung_wallet", status)
                                    .addOnSuccessListener(aVoid -> {
                                        Log.d(TAG, "DocumentSnapshot successfully updated!");
                                        // Refresh the lists
                                        EventChangeListener();
                                    })
                                    .addOnFailureListener(e -> Log.w(TAG, "Error updating document", e));
                        } else {
                            Log.d(TAG, "No matching document found");
                        }
                    } else {
                        Log.w(TAG, "Error getting documents.", task.getException());
                    }
                });
    }

}
