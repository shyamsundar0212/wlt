package com.example.walletapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Locale;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.MyViewHolder> {
    private Context context;
    private ArrayList<User> userArrayList;
    private OnAccountClickListener onAccountClickListener;

    public MyAdapter(Context context, ArrayList<User> userArrayList, OnAccountClickListener onAccountClickListener) {
        this.context = context;
        this.userArrayList = userArrayList;
        this.onAccountClickListener = onAccountClickListener;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item, parent, false);
        return new MyViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        User user = userArrayList.get(position);
        Timestamp expiryTimestamp = user.getExpiry();
        SimpleDateFormat sdf = new SimpleDateFormat("MM/yyyy", Locale.getDefault());
        String expiryDate = sdf.format(expiryTimestamp.toDate());

        holder.expiry.setText(expiryDate);
        holder.bank_name.setText(user.getBank_name());
        holder.acc_num.setText(user.getAcc_num());

        holder.itemView.setOnClickListener(v -> {
            if (onAccountClickListener != null) {
                onAccountClickListener.onAccountClick(user);
            }
        });
    }

    @Override
    public int getItemCount() {
        return userArrayList.size();
    }

    public interface OnAccountClickListener {
        void onAccountClick(User user);
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView expiry, bank_name, acc_num;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            expiry = itemView.findViewById(R.id.expiry);
            bank_name = itemView.findViewById(R.id.bank_name);
            acc_num = itemView.findViewById(R.id.accno);
        }
    }
}
