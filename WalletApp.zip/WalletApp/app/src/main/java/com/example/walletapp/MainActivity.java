package com.example.walletapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {
 private TabLayout tabLayout;
 private ViewPager viewPager;
 private adapter adap;
 private FirebaseAuth auth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        tabLayout=findViewById(R.id.main_tab);
        viewPager=findViewById(R.id.page_viewer);
        auth=FirebaseAuth.getInstance();
        adapter adap=new adapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adap.addFragment(new profile(),R.drawable.baseline_person_outline_24);
        adap.addFragment(new main(),R.drawable.baseline_airplay_24);
        adap.addFragment(new wallet(),R.drawable.baseline_account_balance_wallet_24);
        viewPager.setAdapter(adap);
        tabLayout.setupWithViewPager(viewPager);
        for(int i=0;i<tabLayout.getTabCount();i++){
            if(adap.getFragmentIcon(i)!=null)
                tabLayout.getTabAt(i).setIcon(adap.getFragmentIcon(i));
        }
    }

}