package com.example.walletapp;

import com.google.firebase.Timestamp;

public class User {
    private Timestamp expiry;
    private String bank_name;
    private String acc_num;
    private boolean samsung_wallet;

    public User() {}

    public User(Timestamp expiry, String bank_name, String acc_num, boolean samsung_wallet) {
        this.expiry = expiry;
        this.bank_name = bank_name;
        this.acc_num = acc_num;
        this.samsung_wallet = samsung_wallet;
    }

    public Timestamp getExpiry() {
        return expiry;
    }

    public void setExpiry(Timestamp expiry) {
        this.expiry = expiry;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getAcc_num() {
        return acc_num;
    }

    public void setAcc_num(String acc_num) {
        this.acc_num = acc_num;
    }

    public boolean isSamsung_wallet() {
        return samsung_wallet;
    }

    public void setSamsung_wallet(boolean samsung_wallet) {
        this.samsung_wallet = samsung_wallet;
    }
}
